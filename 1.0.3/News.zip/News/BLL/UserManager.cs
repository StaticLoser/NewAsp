﻿using Model;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class UserManager
    {

        public static bool addUser(string userName, string password)
        {

            User info = UserService.getu(userName);
            if (info != null)
            {
                return false;
            }
            User userInfo = new User();
            userInfo.username = userName;
            userInfo.password = password;
            userInfo.userAvatar = "~/image/1.jpg";
            userInfo.nickName = "今日网瘾少年";
            userInfo.state = 1;
            userInfo.createTime = DateTime.Now;
            userInfo.introduce = "";
            return UserService.addUser(userInfo);
        }

        public static User checkUser(string userName, string password)
        {
            User info = UserService.getu(userName);
            if (info != null && info.password != password)
            {
                return null;
            }
            return info;
        }

        //查询用户信息
        public static User GetUserInfo(string userName)
        {
            User info = UserService.getu(userName);
            if (info == null)
            {
                return null;
            }
            return info;
        }


        public static bool updateUser(User u, string userAvatar, string nickName, string introduce)
        {
            return UserService.updateUser(u, userAvatar, nickName, introduce);
        }
    }
}