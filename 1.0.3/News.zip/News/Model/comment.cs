﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [Serializable]
    class comment
    {
        public int id { get; set; }
        public string Comment { get; set; }
        public int User_id { get; set; }
        public DateTime createTime { get; set; }
        public int state { get; set; }
    }
}
