﻿using System;
using BLL;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Model;
using System.IO;

namespace News
{
    public partial class UserSet : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            User u = UserManager.GetUserInfo(Session["username"].ToString());
            this.Image1.ImageUrl = u.userAvatar;
        }
        protected void layuiBtn_Click(object sender, EventArgs e)
        {
            //数据库查询新建单个用户信息
            User u = UserManager.GetUserInfo(Session["username"].ToString());
            string filename = this.FileUpload1.FileName;
            string fileFix = Path.GetExtension(filename);
            if (fileFix != ".jpg" && fileFix != ".png" && fileFix != ".jpeg" && fileFix != ".gif" && fileFix != ".ttf")
            {
                Response.Write("<script>alert('文件格式不正确')</script>");
                return;
            }

            this.FileUpload1.SaveAs(Server.MapPath("~/Content/Upload/" + filename));
            string filepath = "./Content/Upload/" + filename;


            if (UserManager.updateUser(u, filepath, username.Text, desc.Text))
            {
                Response.Write("<script>alert('修改成功！')</script>");
                this.Image1.ImageUrl = filepath;
            }
            else
            {
                Response.Write("<script>alert('修改失败！')</script>");
            }
        }
    }
}