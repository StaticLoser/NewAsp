﻿using Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class FanService
    {
        //查询粉丝
        public static List<Fans> getFans(int id)
        {
            string sql = $"select u.nickName,u.userAvatar,u.id from Fans left join [User] u on u.id=fans_id where guanzhu_id={id}";
            SqlDataReader dr = DBHelper.getData(sql);
            List<Fans> list = new List<Fans>();
            Fans f = null;
            while (dr.Read())
            {
                f = new Fans()
                {
                    id = int.Parse(dr["id"].ToString()),
                    nickname = dr["nickName"].ToString(),
                    userAvatar = dr["userAvatar"].ToString()
                };
                list.Add(f);
            }
            dr.Close();
            return list;
        }

        //查询关注
        public static List<Fans> getGuanZhu(int id)
        {
            string sql = $"select u.nickName,u.userAvatar,u.id from Fans left join [User] u on u.id=guanzhu_id where fans_id={id}";
            SqlDataReader dr = DBHelper.getData(sql);
            List<Fans> list = new List<Fans>();
            Fans f = null;
            while (dr.Read())
            {
                f = new Fans()
                {
                    id = int.Parse(dr["id"].ToString()),
                    nickname = dr["nickName"].ToString(),
                    userAvatar = dr["userAvatar"].ToString()
                };
                list.Add(f);
            }
            dr.Close();
            return list;
        }

        //查询粉丝总数
        public static int getFansNum(int id)
        {
            string sql = $"select Count(*) from Fans left join [User] u on u.id=fans_id where guanzhu_id={id}";
            DataTable dt = DBHelper.getDataTable(sql);
            int res = 0;
            if (dt != null)
            {
                res = int.Parse(dt.Rows[0][0].ToString());
            }
            return res;
        }

        //查询关注总数
        public static int getGuanZhuNum(int id)
        {
            string sql = $"select Count(*) from Fans left join [User] u on u.id=fans_id where fans_id={id}";
            DataTable dt = DBHelper.getDataTable(sql);
            int res = 0;
            if (dt != null)
            {
                res = int.Parse(dt.Rows[0][0].ToString());
            }
            return res;
        }
    }
}
