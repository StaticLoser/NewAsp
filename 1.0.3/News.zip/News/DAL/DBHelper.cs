﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
   public class DBHelper
    {
        //数据库连接配置字符串
        public static string conStr = "Data Source=.;Initial Catalog=News;Integrated Security=True; MultipleActiveResultSets=true";
        //public static string conStr = "Data Source=.;Initial Catalog=News;Persist Security Info=True; MultipleActiveResultSets=true; User ID=sa;Password=JSB903..";
        public static SqlConnection conn = null;

        public static void Open()
        {
            if (conn == null)
            {
                conn = new SqlConnection(conStr);
            }
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
        }
        public static void Closed()
        {
           
            if (conn.State == System.Data.ConnectionState.Open)
            {
                conn.Close();
            }
        }
        //对数据库执行增删改方法
        public static bool updateData(string sql)
        {
            Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            int result = cmd.ExecuteNonQuery();
            return result > 0;
        }
        //对数据库执行查询方法
        public static SqlDataReader getData(string sql)
        {
            Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            return dr;
        }

        public static DataTable getDataTable(string sql)
        {
            Open();           
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return (ds.Tables[0]);
        }
    }
}
