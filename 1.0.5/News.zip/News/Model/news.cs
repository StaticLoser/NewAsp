﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [Serializable]
   public class news
    {
        public int id { get; set; }
        public string title { get; set; }
        public string content { get; set; }
        public int User_id { get; set; }
        public int state { get; set; }
        public DateTime createTime { get; set; }
        public string img { get; set; }

        //分类id
        public int Category_id { get; set; }
        //分类名
        public string catename { get; set; }
        //用户昵称
        public string nickName { get; set; }
        //用户头像
        public string userAvatar { get; set; }

    }
}
