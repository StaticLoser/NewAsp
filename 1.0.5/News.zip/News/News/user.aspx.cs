﻿using BLL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace News
{
    public partial class user : System.Web.UI.Page
    {

        public static string Img = "";
        public static string nickName = "";
        public static int FansCount = 0;
        public static int GuanZhu = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            
            getCategoryList();
            getUserInfo();
            getUserNewList();
            getGuanZhuNum();
            getFansNum();
            //GetCategoryListMore();
        }

        private void getGuanZhuNum()
        {
            int id = (Session["userinfo"] as User).id;
            GuanZhu = FanManager.getGuanZhuNum(id);
        }

        private void getFansNum()
        {
            int id = (Session["userinfo"] as User).id;
            FansCount = FanManager.getFansNum(id);
        }

        //取得用户发表的新闻
        private void getUserNewList()
        {
            this.UserNewList.DataSource = NewsManager.getUserNesList((Session["userinfo"] as User).id);
            this.UserNewList.DataBind();
        }

        private void GetCategoryListMore()
        {
            this.categoryMore.DataSource = CategoryManager.GetCategoryListMore();
            this.categoryMore.DataBind();
        }

        private void getCategoryList()
        {
            this.Repeater1.DataSource = CategoryManager.GetCategoryList();
            this.Repeater1.DataBind();
        }

        private void getUserInfo()
        {
            if (Session["userinfo"] != null)
            {
                Img = (Session["userinfo"] as User).userAvatar;
                nickName = (Session["userinfo"] as User).nickName;
            }
        }
    }
}