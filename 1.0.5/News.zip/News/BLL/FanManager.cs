﻿using Model;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class FanManager
    {
        public static List<Fans> getFans(int id)
        {
            return FanService.getFans(id);
        }

        //查询粉丝总数
        public static int getFansNum(int id)
        {
            return FanService.getFansNum(id);
        }

        //查询关注总数
        public static int getGuanZhuNum(int id)
        {
            return FanService.getGuanZhuNum(id);
        }

        public static List<Fans> getGuanZhu(int id)
        {
            return FanService.getGuanZhu(id);
        }

        //关注用户
        public static bool AddGuanzhu(int u_id, int Guanzhu_id)
        {
            return FanService.AddGuanzhu(u_id, Guanzhu_id);
        }

        //取消关注
        public static bool CenaleUser(int u_id, int Guanzhu_id)
        {

            return FanService.CenaleUser(u_id, Guanzhu_id);
        }
        /// <summary>
        /// 查询是否关注
        /// </summary>
        /// <param name="u_id"></param>
        /// <param name="Guanzhu_id"></param>
        /// <returns></returns>
        public static bool SelectFans(int u_id, int Guanzhu_id)
        {
            return FanService.SelectFans(u_id, Guanzhu_id);
        }
    }
}
