﻿using Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class FanService
    {
        /// <summary>
        /// 粉丝信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static List<Fans> getFans(int id)
        {
            string sql = $"select u.nickName,u.userAvatar,u.id from Fans left join [User] u on u.id=fans_id where guanzhu_id={id}";
            SqlDataReader dr = DBHelper.getData(sql);
            List<Fans> list = new List<Fans>();
            Fans f = null;
            while (dr.Read())
            {
                f = new Fans()
                {
                    id = int.Parse(dr["id"].ToString()),
                    nickname = dr["nickName"].ToString(),
                    userAvatar = dr["userAvatar"].ToString()
                };
                list.Add(f);
            }
            dr.Close();
            return list;
        }

        /// <summary>
        /// 查询关注
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static List<Fans> getGuanZhu(int id)
        {
            string sql = $"select u.nickName,u.userAvatar,u.id from Fans left join [User] u on u.id=guanzhu_id where fans_id={id}";
            SqlDataReader dr = DBHelper.getData(sql);
            List<Fans> list = new List<Fans>();
            Fans f = null;
            while (dr.Read())
            {
                f = new Fans()
                {
                    id = int.Parse(dr["id"].ToString()),
                    nickname = dr["nickName"].ToString(),
                    userAvatar = dr["userAvatar"].ToString()
                };
                list.Add(f);
            }
            dr.Close();
            return list;
        }

        /// <summary>
        /// 粉丝总数
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static int getFansNum(int id)
        {
            string sql = $"select Count(*) from Fans left join [User] u on u.id=fans_id where guanzhu_id={id}";
            DataTable dt = DBHelper.getDataTable(sql);
            int res = 0;
            if (dt != null)
            {
                res = int.Parse(dt.Rows[0][0].ToString());
            }
            return res;
        }

        /// <summary>
        /// 关注总数
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static int getGuanZhuNum(int id)
        {
            string sql = $"select Count(*) from Fans left join [User] u on u.id=fans_id where fans_id={id}";
            DataTable dt = DBHelper.getDataTable(sql);
            int res = 0;
            if (dt != null)
            {
                res = int.Parse(dt.Rows[0][0].ToString());
            }
            return res;
        }

        /// <summary>
        /// 检查是否关注该用户
        /// </summary>
        /// <param name="u_id"></param>
        /// <param name="Guanzhu_id"></param>
        /// <returns></returns>
        public static bool SelectFans(int u_id, int Guanzhu_id)
        {
            string sql = $"select * from fans where fans_id={u_id} and guanzhu_id={Guanzhu_id}";
            SqlDataReader dr = DBHelper.getData(sql);
            if (dr.Read())
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 关注用户
        /// </summary>
        /// <param name="u_id"></param>
        /// <param name="Guanzhu_id"></param>
        /// <returns></returns>
        public static bool AddGuanzhu(int u_id, int Guanzhu_id)
        {
            string sql = $"insert into Fans (fans_id,guanzhu_id)values({u_id},{Guanzhu_id})";
            return DBHelper.updateData(sql);
        }
        /// <summary>
        /// 取消关注
        /// </summary>
        /// <param name="u_id">粉丝id</param>
        /// <param name="Guanzhu_id">关注人id</param>
        /// <returns></returns>
        public static bool CenaleUser(int u_id, int Guanzhu_id)
        {
            string sql = $"delete from fans where fans_id={u_id} and guanzhu_id={Guanzhu_id}";
            return DBHelper.updateData(sql);
        }

    }
}