﻿using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class NewsManager
    {
        public static List<news> GetNewsList()
        {
            return NewsService.getNewsList();
        }
        public static news getNewsDetail(int id)
        {
            return NewsService.getNewsDetail(id);
        }

        public static List<news> getUserNesList(int id)
        {
            return NewsService.getUserNesList(id);
        }

        public static bool addNews(news n)
        {
            return NewsService.addNews(n);
        }
    }
}
