﻿using Model;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class FanManager
    {
        public static List<Fans> getFans(int id)
        {
            return FanService.getFans(id);  
        }

        //查询粉丝总数
        public static int getFansNum(int id)
        {
            return FanService.getFansNum(id);
        }
        //查询关注总数
        public static int getGuanZhuNum(int id)
        {
            return FanService.getGuanZhuNum(id);
        }
        public static List<Fans> getGuanZhu(int id)
        {
            return FanService.getGuanZhu(id);
        }
    }
}
