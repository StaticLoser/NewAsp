﻿using Model;
using BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace News
{
    public partial class followandfans : System.Web.UI.Page
    {
        public static string Img = "";
        public static string nickName = "";
        public static int FansCount = 0;
        public static int GuanZhu = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            //得到用户信息
            getUserInfo();
            //得到粉丝信息
            getFansInfo();
            //得到关注用户信息
            getGuanzhu();
            getGuanZhuNum();
            getFansNum();
        }

        private void getGuanZhuNum()
        {
            int id = (Session["userinfo"] as User).id;
            GuanZhu = FanManager.getGuanZhuNum(id);
        }

        private void getFansNum()
        {
            int id = (Session["userinfo"] as User).id;
            FansCount = FanManager.getFansNum(id);
        }
        private void getGuanzhu()
        {
            int id = (Session["userinfo"] as User).id;
            this.Guanzhu.DataSource = FanManager.getGuanZhu(id);
            this.Guanzhu.DataBind();
        }

        private void getFansInfo()
        {
            int id = (Session["userinfo"] as User).id;
            this.Fanas.DataSource = FanManager.getFans(id);
            this.Fanas.DataBind();
        }



        private void getUserInfo()
        {
            if (Session["userinfo"] != null)
            {
                Img = (Session["userinfo"] as User).userAvatar;
                nickName = (Session["userinfo"] as User).nickName;
            }
        }
       

    }
}