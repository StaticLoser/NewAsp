$('.change').click(function() {
	$('.change').removeClass('activeC')
	$(this).addClass('activeC')
	var index = $(this).index()
	if (index == 0) {
		$(".loginBox").show()
		$(".regres").hide()
	} else {
		$(".loginBox").hide()
		$(".regres").show()
	}
})


//$("#regUserName").blur(function() {
//	var msg = $(this).val()
//	console.log(msg.trim().length)

//	if (msg.length == 0) {
//		$(this).next().text("用户名必填")
//	} else {
//		$(this).next().text("")
//	}
//});


//$("#regPassword").blur(function() {
//	var msg = $(this).val()
//	console.log(msg.trim().length)

//	if (msg.length == 0) {
//		$(this).next().text("密码必填")
//	} else {
//		$(this).next().text("")
//	}
//});

//$("#regVerifyPass").blur(function() {
//	var regpass = $(this).val()
//	if (regpass.length == 0) {
//		$(this).next().text("确认密码必填")
//	} else {
//		$(this).next().text("")
//	}
//	if (regpass.length > 0) {
//		var msg = $(this).parent().prev().children().next().val()
//		if (msg != regpass) {
//			$(this).next().text('密码不一致')
//		}
//	} else {
//		$(this).next().text("")
//	}
//});
