﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    /// <summary>
    /// 新闻表的操作
    /// </summary>
    public class NewsService
    {
        //查询新闻列表
        public static List<news> getNewsList()
        {
            string sql = $"select n.*,c.catename,u.nickName,u.userAvatar from news n left join [user] u on n.user_id = u.id left join category c on n.category_id = c.id";
            SqlDataReader dr = DBHelper.getData(sql);
            List<news> list = new List<news>();
            news news = null;
            while (dr.Read())
            {
                news = new news()
                {
                    id = int.Parse(dr["id"].ToString()),
                    catename = dr["cateName"].ToString(),
                    title = dr["title"].ToString(),
                    content = dr["content"].ToString(),
                    User_id = int.Parse(dr["User_id"].ToString()),
                    Category_id = int.Parse(dr["Category_id"].ToString()),
                    state = int.Parse(dr["state"].ToString()),
                    createTime = DateTime.Parse(dr["createtime"].ToString()),
                    img = dr["img"].ToString(),
                    nickName = dr["nickName"].ToString(),
                    userAvatar = dr["userAvatar"].ToString()
                };
                list.Add(news);
            }
            dr.Close();
            return list;
        }
        //新闻id查询新闻详情
        public static news getNewsDetail(int id)
        {
            string sql = $"select n.*,c.catename,u.nickName,u.userAvatar from news n left join [user] u on n.user_id = u.id left join category c on n.category_id = c.id where n.id={id}";
            SqlDataReader dr = DBHelper.getData(sql);
            news news = null;
            if (dr.Read())
            {
                news = new news()
                {
                    id = int.Parse(dr["id"].ToString()),
                    catename = dr["cateName"].ToString(),
                    title = dr["title"].ToString(),
                    content = dr["content"].ToString(),
                    User_id = int.Parse(dr["User_id"].ToString()),
                    Category_id = int.Parse(dr["Category_id"].ToString()),
                    state = int.Parse(dr["state"].ToString()),
                    createTime = DateTime.Parse(dr["createtime"].ToString()),
                    img = dr["img"].ToString(),
                    nickName = dr["nickName"].ToString(),
                    userAvatar = dr["userAvatar"].ToString()
                };
            }
            dr.Close();
            return news;
        }

        //添加新闻
        public static bool addNews(string title,string content,int u_id,int c_id,string img)
        {
            string sql = $"insert into news (tite,content,[User_id],[Category_id],[state],createtime,img)values('{title}','{content}','{u_id}','{c_id}',1,{DateTime.Now},'{img}')";
            return DBHelper.updateData(sql);
        }

        public static List<news> getUserNesList(int id)
        {
            string sql = $"select * from news left join Category c on c.id=Category_id left join [User] u on u.id=[User_id] where [User_id]={id}";
            SqlDataReader dr = DBHelper.getData(sql);
            List<news> list = new List<news>();
            news n = null;
            while (dr.Read())
            {
                n = new news()
                {
                    id = int.Parse(dr["id"].ToString()),
                    catename = dr["cateName"].ToString(),
                    title = dr["title"].ToString(),
                    content = dr["content"].ToString(),
                    User_id = int.Parse(dr["User_id"].ToString()),
                    Category_id = int.Parse(dr["Category_id"].ToString()),
                    state = int.Parse(dr["state"].ToString()),
                    createTime = DateTime.Parse(dr["createtime"].ToString()),
                    img = dr["img"].ToString(),
                    nickName = dr["nickName"].ToString(),
                    userAvatar = dr["userAvatar"].ToString()
                };
                list.Add(n);
            }
            dr.Close();
            return list;
        }
    }
}
