﻿using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class LinksManager
    {
        public static List<Links> getNewsListLess45()
        {
            return LinkService.getNewsListLess45();
        }
        public static List<Links> getNewsListMore45()
        {
            return LinkService.getNewsListMore45();
        }
    }
}
