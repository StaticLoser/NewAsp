﻿using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class CategoryManager
    {
        public static List<category> GetCategoryList()
        {
            return CategoryService.GetCategoryList();
        }

        public static List<category> GetCategoryListMore()
        {
            return CategoryService.GetCategoryListMore();
        }
        //全部分类
        public static List<category> getCategory()
        {
            return CategoryService.getCategory();
        }
    }
}
