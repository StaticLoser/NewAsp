﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [Serializable]
    public class User
    {
        public int id { get; set; }
        public string username { get; set; }
        public string   password { get; set; }
        public string nickName { get; set; }
        public string userAvatar { get; set; }
        public DateTime createTime { get; set; }
        public string introduce { get; set; }
        public int state { get; set; }
    }
}
