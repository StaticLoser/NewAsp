﻿using System;
using BLL;
using Model;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace News
{
    public partial class UserPost : System.Web.UI.Page
    {
        string content = "";
      
        protected void Page_Load(object sender, EventArgs e)
        {
            getcategory();
            content = this.demo.InnerText.ToString();
            //User u = (Session["userinfo"] as User);
            //user_id = u.id;
            //category_id = int.Parse(this.categoryList.DataValueField);
        }

        protected void sub_Click(object sender, EventArgs e)
        {
            //往新闻表插入数据

            //getcategory();
        }

        private void getcategory()
        {
            this.categoryList.DataSource = CategoryManager.getCategory();
            this.categoryList.DataTextField = "catename";
            this.categoryList.DataValueField = "id";
            this.categoryList.DataBind();
        }
    }
}