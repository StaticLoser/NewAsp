﻿using System;
using BLL;
using Model;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace News
{
    public partial class NewDetail : System.Web.UI.Page
    {
        public static string title = "";
        public static string nickname = "";
        public static string catename = "";
        public static string content = "";
        public static string createtime = "";
        public static string userAvatar = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            getTapBar();
            Response.Write($"<script>alert({Request["id"]})</script>");
            getNewDetail();
        }

        private void getNewDetail()
        {
            int id = int.Parse(Request["id"]);
            news n = NewsManager.getNewsDetail(id);
            content = n.content;
             title = n.title;
            nickname = n.nickName;
            catename = n.catename;
            createtime = n.createTime.ToString();
            userAvatar = n.userAvatar;
        }

        private void getTapBar()
        {
            this.tapBar.DataSource = CategoryManager.GetCategoryList();
            DataBind();
        }
    }
}