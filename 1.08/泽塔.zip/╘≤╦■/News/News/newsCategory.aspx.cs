﻿using BLL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace News
{
    public partial class newsCategory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dateShow();
            }           
        }

        private void dateShow()
        {
            this.CategoryGridView.DataSource = CategoryManager.getCategoryTable();
            this.CategoryGridView.DataBind();
        }

        protected void CategoryGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            CategoryGridView.PageIndex = e.NewPageIndex;
            dateShow();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            this.CategoryGridView.DataSource = CategoryManager.getCateList(this.catename.Text);
            this.CategoryGridView.DataBind();
        }

        protected void CategoryGridView_RowEditing(object sender, GridViewEditEventArgs e)
        {
            CategoryGridView.EditIndex = e.NewEditIndex;
            dateShow();
        }

        protected void CategoryGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            //修改分类
            category c = new category()
            {
                id = int.Parse(((TextBox)(CategoryGridView.Rows[e.RowIndex].Cells[0].Controls[0])).Text.ToString()),
                catename = ((TextBox)(CategoryGridView.Rows[e.RowIndex].Cells[1].Controls[0])).Text.ToString(),               
            };
            if (CategoryManager.UpdateCategory(c))
            {
                Response.Write($"<script>alert('成功')</script>");
                Response.Write($"<script>alert('{c.id}')</script>");
                Response.Write($"<script>alert('{c.catename}')</script>");

                CategoryGridView.EditIndex = -1;
                dateShow();
            }
            else
            {
                Response.Write($"<script>alert('失败')</script>");
                CategoryGridView.EditIndex = -1;
                dateShow();
                return;
            }
        }

        protected void CategoryGridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            CategoryGridView.EditIndex = -1;
            dateShow();
        }
    }
}