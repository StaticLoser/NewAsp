﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace DAL
{
    public class UserService
    {
        //增加用户
        public static bool addUser(User u)
        {
            string sql = $"insert into [user] (username,password,userAvatar,nickName,introduce,state,createTime) values('{u.username}','{u.password}','{u.userAvatar}','{u.nickName}','{u.introduce}','{u.state}','{u.createTime}')";

            return DBHelper.updateData(sql);
        }
        //修改用户
        public static bool updateData(User u)
        {
            string sql = $"UPDATE [dbo].[User] SET [username] = {u.username},[password] = {u.password},[nickName] = {u.nickName},[createtime] = {u.createTime},[introduce] = {u.introduce},[state] = {u.state} WHERE id={u.id}";
            return DBHelper.updateData(sql);
        }


        //用户修改信息
        public static bool updateUser(User u, string userAvatar, string nickName, string introduce)
        {
            string sql = $"update [user] set username='{u.username}',password='{u.password}',userAvatar='{userAvatar}',nickName='{nickName}',introduce='{introduce}',state='{u.state}',createTime='{u.createTime}' where username='{u.username}'";
            return DBHelper.updateData(sql);
        }

        //查询用户
        public static User getu(string userName)
        {
            string sql = $"select * from [user] where username='{userName}'";

            SqlDataReader dr = DBHelper.getData(sql);
            User u = null;
            if (dr.Read())
            {
                u = new User();
                u.id = dr.GetInt32(0);
                u.username = dr.GetString(1);
                u.password = dr.GetString(2);
                u.nickName = dr.GetString(3);
                u.userAvatar = dr.GetString(4);
                u.createTime = dr.GetDateTime(5);
                u.introduce = dr.GetString(6);
                u.state = dr.GetInt32(7);
            }
            return u;
        }

        /// <summary>
        /// 模糊查询用户信息
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        public static List<User> getUserList(string username)
        {
            string sql = $"select * from [user] where username like '%{username}%'";
            SqlDataReader dr = DBHelper.getData(sql);
            List<User> list = new List<User>();
            User u = null;
            while (dr.Read())
            {
                u = new User()
                {
                    id = dr.GetInt32(0),
                    username = dr.GetString(1),
                    password = dr.GetString(2),
                    nickName = dr.GetString(3),
                    userAvatar = dr.GetString(4),
                    createTime = dr.GetDateTime(5),
                    introduce = dr.GetString(6),
                    state = dr.GetInt32(7),
                };
                list.Add(u);
            }
            return list;
        }
        public static DataTable GetUserTable()
        {
            string sql = "SELECT [id],[username],[password] ,[nickName] ,[createtime] ,[introduce],[state] FROM [dbo].[User]";
            return DBHelper.getDataTable(sql);
            
        }
    }
}