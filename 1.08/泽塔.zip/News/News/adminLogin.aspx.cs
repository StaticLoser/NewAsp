﻿using BLL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace News
{
    public partial class adminLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void loginBtn_Click(object sender, EventArgs e)
        {
            admin a = adminManager.CheckAdmin(this.userName.Text, this.passWord.Text);

            if (a != null)
            {
                Session["admin"] = a;
                Session["adminName"] = a.adminstorName;
                Response.Write("<script> location.href='adminIndex.aspx'</script>");
            }
            else
            {
                Response.Write("<script>alert('登录失败！');</script>");
                return;
            }
        }
    }
}