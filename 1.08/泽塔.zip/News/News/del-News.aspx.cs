﻿using BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace News
{
    public partial class del_News : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dataShow();
            }
        }

        private void dataShow()
        {
            this.NewsGridView.DataSource = NewsManager.getNewsTable();
            this.NewsGridView.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            this.NewsGridView.DataSource = NewsManager.getNewsList(this.title.Text);
            this.NewsGridView.DataBind();
        }
    }
}