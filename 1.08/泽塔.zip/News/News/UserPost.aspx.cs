﻿using System;
using BLL;
using Model;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace News
{
    public partial class UserPost : System.Web.UI.Page
    {

        public static string tit = "";
        public static string content = "";
        public static string imgPath = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getcategory();
            }

        }

        protected void sub_Click(object sender, EventArgs e)
        {
            content = this.demo.InnerText;
            tit = this.title.Text;
            string c_id = this.categoryList.Text;
            string path = "";
            int u_id = (Session["userinfo"] as User).id;
            if (this.ImgUpload.HasFile)
            {
                string filename = ImgUpload.FileName;
                string back = Path.GetExtension(filename).ToLower();
                if (back != ".jpg" && back != ".jpeg" && back != ".gif" && back != ".ttf" && back != ".png")
                {
                    Response.Write("<script>alert('图片格式不支持')</script>");
                    return;
                }
                path = "/Content/Upload/NewsDetailImg/" + DateTime.Now.ToString("yyMMss") + "_" + filename;
                ImgUpload.SaveAs(Server.MapPath(path));
            }
            else
            {
                Response.Write("<script>alert('请上传图片')</script>");
                return;
            }
            //Response.Write($"{tit}+{content}+{c_id}+{u_id}");
            news n = new news()
            {
                title = tit,
                content = content,
                User_id = u_id,
                Category_id = int.Parse(c_id),
                img = path
            };
            if (NewsManager.addNews(n))
            {
                Response.Write("<script>alert('发布成功！')</script>");
                Response.Redirect("Index.aspx");
            }
            else
            {
                Response.Write("<script>alert('发布失败！')</script>");
                return;
            }
        }

        private void getcategory()
        {
            this.categoryList.DataSource = CategoryManager.getCategory();
            this.categoryList.DataTextField = "catename";
            this.categoryList.DataValueField = "id";
            this.categoryList.DataBind();
        }
    }
}