﻿using BLL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace News
{
    public partial class admin_del : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getdate();
            }

        }

        private void getdate()
        {
            this.UserGridView.DataSource = UserManager.getUserData();
            this.UserGridView.DataBind();
        }

        protected void UserGridView_RowEditing(object sender, GridViewEditEventArgs e)
        {

            UserGridView.EditIndex = e.NewEditIndex;
            getdate();
        }

        protected void UserGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            User u = new User()
            {
                id = int.Parse(((TextBox)(UserGridView.Rows[e.RowIndex].Cells[0].Controls[0])).Text.ToString()),
                username = ((TextBox)(UserGridView.Rows[e.RowIndex].Cells[1].Controls[0])).Text.ToString(),
                password = ((TextBox)(UserGridView.Rows[e.RowIndex].Cells[2].Controls[0])).Text.ToString(),
                nickName = ((TextBox)(UserGridView.Rows[e.RowIndex].Cells[3].Controls[0])).Text.ToString(),
                createTime = DateTime.Parse(((TextBox)(UserGridView.Rows[e.RowIndex].Cells[4].Controls[0])).Text.ToString()),
                introduce = ((TextBox)(UserGridView.Rows[e.RowIndex].Cells[5].Controls[0])).Text.ToString(),
                state = int.Parse(((TextBox)(UserGridView.Rows[e.RowIndex].Cells[6].Controls[0])).Text.ToString())
            };
            if (UserManager.updateData(u))
            {
                Response.Write($"<script>alert('成功')</script>");
                UserGridView.EditIndex = -1;
                getdate();
            }
            else
            {
                Response.Write($"<script>alert('失败')</script>");
                UserGridView.EditIndex = -1;
                getdate();
                return;
            }

        }

        protected void UserGridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            UserGridView.EditIndex = -1;
            getdate();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            this.UserGridView.DataSource =UserManager.getUserList(this.username.Text);
            this.UserGridView.DataBind();
        }
    }
}