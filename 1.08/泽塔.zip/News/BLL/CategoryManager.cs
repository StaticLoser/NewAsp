﻿using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class CategoryManager
    {
        public static List<category> GetCategoryList()
        {
            return CategoryService.GetCategoryList();
        }

        public static List<category> GetCategoryListMore()
        {
            return CategoryService.GetCategoryListMore();
        }
        //全部分类
        public static List<category> getCategory()
        {
            return CategoryService.getCategory();
        }

        public static DataTable getCategoryTable()
        {
            return CategoryService.getCategoryTable();
        }
        /// <summary>
        ///模糊查询分类
        /// </summary>
        /// <param name="cate"></param>
        /// <returns></returns>
        public static List<category> getCateList(string cate)
        {
            return CategoryService.getCateList(cate);
        }


        /// <summary>
        /// 修改分类
        /// </summary>
        /// <param name="c">实例化的category类</param>
        /// <returns></returns>
        public static bool UpdateCategory(category c)
        {
            return CategoryService.UpdateCategory(c);
        }
    }
}
