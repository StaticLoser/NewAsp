﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [Serializable]
    public class Fans
    {
        //粉丝表
        public int id { get; set; }
        public int fans_id { get; set; }
        public int guanzhu_id { get; set; }
        public string nickname { get; set; }

        public string userAvatar { get; set; }
    }
}
