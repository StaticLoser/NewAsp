﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using Model;

namespace News
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //生成验证码
            if (!IsPostBack)
            {
                checkVerify();
            }
        }

        private void checkVerify()
        {
            Random ran = new Random();
            this.logVerifCode.Text = ran.Next(1000, 9999).ToString();
        }

        //注册
        protected void regBtn_Click(object sender, EventArgs e)
        {
            string username = this.regUserName.Text;
            string password = this.regPassword.Text;

            if (UserManager.addUser(username, password))
            {
                Response.Write("<script>alert('注册成功')</script>");
            }
            else
            {
                Response.Write("<script>alert('注册失败')</script>");
            }
        }

        //验证
        protected void LoginBtn_Click(object sender, EventArgs e)
        {
            string username = this.logUserName.Text;
            string password = this.userPass.Text;
            string logVerif = this.logVerifyPass.Text;
            string logVerifCode = this.logVerifCode.Text;

            if (username.ToString().Trim() == string.Empty)
            {
                Response.Write("<script>alert('用户名不能为空！')</script>"); return;
            }
            if (password.ToString().Trim() == string.Empty)
            {
                Response.Write("<script>alert('密码不能为空！')</script>"); return;
            }
            if (logVerif.ToString().Trim() == string.Empty)
            {
                Response.Write("<script>alert('验证码不能为空！')</script>"); return;
            }
            if (this.logVerifyPass.Text != logVerifCode)
            {
                checkVerify();
                Response.Write("<script>alert('验证码不正确！')</script>"); return;
            }
            User userInfo = UserManager.checkUser(username, password);
            if (userInfo != null)
            {
                if (userInfo.state == 1)
                {
                    Response.Write("<script>alert('登录成功！')</script>");
                    //进行跳转到某个页面
                    //用SESSION记住用户信息，可以在别的页面去使用这个信息
                    Session["userinfo"] = userInfo;
                    Session["Username"] = username;
                    Response.Redirect("~/Index.aspx");
                }
                else
                {
                    Response.Write("<script>alert('权限不足登录失败！')</script>");
                    return;
                }
            }
            else
            {
                checkVerify();
                Response.Write("<script>alert('登录失败 用户名或者密码错误！')</script>");
            }
        }
    }
}