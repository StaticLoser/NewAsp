﻿using System;
using BLL;
using Model;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace News
{
    public partial class NewDetail : System.Web.UI.Page
    {
        public static string title = "";
        //作者id
        public static int Autherid = 0;
        //用户id
        public static int useUserId = 0;
        public static string nickname = "";
        public static string catename = "";
        public static string content = "";
        public static string createtime = "";
        public static string userAvatar = "";
        public static bool check = false;
        protected void Page_Load(object sender, EventArgs e)
        {
            //Response.Write($"<script>alert({Request["id"]})</script>");
            if (!IsPostBack)
            {
                getTapBar();
                getNewDetail();
                getDetail();
                string str = this.button.Text;
                if (Session["userinfo"] != null)
                {
                    useUserId = (Session["userinfo"] as User).id;
                }
                //Response.Write($"<script>alert('{button.Text}')</script>");
                //Response.Write($"<script>alert('{Autherid}')</script>");
            }
            check = FanManager.SelectFans(useUserId, Autherid);
        }

        private void getDetail()
        {
            this.Literal1.Text = content;
        }

        private void getNewDetail()
        {
            int id = int.Parse(Request["id"]);
            news n = NewsManager.getNewsDetail(id);
            Autherid = n.User_id;
            content = n.content;
            title = n.title;
            nickname = n.nickName;
            catename = n.catename;
            createtime = n.createTime.ToString();
            userAvatar = n.userAvatar;
        }

        private void getTapBar()
        {
            this.tapBar.DataSource = CategoryManager.GetCategoryList();
            DataBind();
        }

        protected void button_Click(object sender, EventArgs e)
        {

            //if (button.Text == "已关注")
            //{
            //    //取消关注
            //    //Response.Write($"<script>alert('{button.Text}')</script>");
            //    Response.Redirect(Request.Url.ToString());
            //    this.button.Text = "关注";
            //}
            //else
            //{
            //    //关注用户
            //    //Response.Write($"<script>alert('未关注')</script>");
            //    Response.Redirect(Request.Url.ToString());
            //    this.button.Text = "已关注";
            //}

            if (Session["userinfo"] != null)
            {
                if (FanManager.AddGuanzhu(useUserId, Autherid))
                {
                //Response.Write($"<script>alert('关注成功！')</script>");
                    check = false;
                    Response.Redirect(Request.Url.ToString());
                    this.button.Text = "已关注";
                }
                else
                {
                    //Response.Write($"<script>alert('关注失败！')</script>");
                    Response.Redirect(Request.Url.ToString());
                    this.button.Text = "关注";
                    return;
                }
            }
            else
            {
                Response.Redirect("index.aspx");
            }

        }
        /// <summary>
        /// 取消关注
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void button1_Click(object sender, EventArgs e)
        {
            if (Session["userinfo"] != null)
            {
                if (FanManager.CenaleUser(useUserId, Autherid))
                {
                    //Response.Write($"<script>alert('取消关注成功！')</script>");
                    check = true;
                    Response.Redirect(Request.Url.ToString());
                    this.button.Text = "关注";
                }
                else
                {
                    //Response.Write($"<script>alert('取消关注失败！')</script>");
                    Response.Redirect(Request.Url.ToString());
                    this.button.Text = "已关注";
                    return;
                }
            }
            else
            {
                Response.Redirect("index.aspx");
            }
        }
    }
}