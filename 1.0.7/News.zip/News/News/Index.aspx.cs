﻿using System;
using BLL;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Model;

namespace News
{
    public partial class Index : System.Web.UI.Page
    {
        public static string Img = "";
        public static string nickName = "";
        public static int FansCount = 0;
        public static int GuanZhu = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            getUserInfo();
            getNewList();
            getCategoryList();
            getLinksList();
            GetCategoryListMore();
            getNewsListMore45();
            getfans();
            getFansNum();
            getGuanZhuNum();            
        }

        private void getGuanZhuNum()
        {
            if (Session["userinfo"] != null)
            {
                int id = (Session["userinfo"] as User).id;
                GuanZhu = FanManager.getGuanZhuNum(id);

            }
        }

        private void getFansNum()
        {
            if (Session["userinfo"] != null)
            {
                int id = (Session["userinfo"] as User).id;
                FansCount = FanManager.getFansNum(id);
            }
        }

        private void getfans()
        {
            if (Session["userinfo"] != null)
            {

                int id = (Session["userinfo"] as User).id;
                List<Fans> f = FanManager.getFans(id);
            }

        }

        //获取相关链接
        private void getNewsListMore45()
        {
            linkMore.DataSource = LinksManager.getNewsListMore45();
            this.linkMore.DataBind();
        }

        private void getUserInfo()
        {
            if (Session["userinfo"] != null)
            {
                Img = (Session["userinfo"] as User).userAvatar;
                nickName = (Session["userinfo"] as User).nickName;
            }
        }

        //获取友情链接列表
        private void getLinksList()
        {
            linksList.DataSource = LinksManager.getNewsListLess45();
            this.linksList.DataBind();
        }



        //获取前几行分类列表
        private void getCategoryList()
        {
            this.Repeater1.DataSource = CategoryManager.GetCategoryList();
            this.Repeater2.DataSource = CategoryManager.GetCategoryList();
            this.Repeater2.DataBind();
            this.Repeater1.DataBind();
        }

        //获取后几行分类列表
        private void GetCategoryListMore()
        {
            this.categoryMore.DataSource = CategoryManager.GetCategoryListMore();
            this.categoryMore.DataBind();
        }
        //获取新闻列表
        private void getNewList()
        {
            this.NewList.DataSource = NewsManager.GetNewsList();
            this.NewList.DataBind();
        }


        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/login.aspx");
            Response.Write("<script>alert('绑定成功')</script>");
        }

        protected void btnPost_Click(object sender, EventArgs e)
        {
            Response.Redirect("UserPost.aspx");
        }
    }
}