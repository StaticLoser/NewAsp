﻿using Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class CategoryService
    {
        //获取id<=7的分类信息
        public static List<category> GetCategoryList()
        {
            string sql = "select * from category where id<7";
            SqlDataReader dr = DBHelper.getData(sql);
            List<category> list = new List<Model.category>();
            category cate = null;
            while (dr.Read())
            {
                cate = new category()
                {
                    catename = dr["cateName"].ToString(),
                    id = int.Parse(dr["id"].ToString()),
                    createTime = DateTime.Parse(dr["createTime"].ToString())
                };
                list.Add(cate);
            }
            dr.Close();
            return list;
        }
        //获取id>7的分类信息
        public static List<category> GetCategoryListMore()
        {
            string sql = "select * from category where id>7";
            SqlDataReader dr = DBHelper.getData(sql);
            List<category> list = new List<Model.category>();
            category cate = null;
            while (dr.Read())
            {
                cate = new category()
                {
                    catename = dr["cateName"].ToString(),
                    id = int.Parse(dr["id"].ToString()),
                    createTime = DateTime.Parse(dr["createTime"].ToString())
                };
                list.Add(cate);
            }
            dr.Close();
            return list;
        }

        //查询所有分类信息
        public static List<category> getCategory()
        {
            string sql = "select * from category";
            SqlDataReader dr = DBHelper.getData(sql);
            List<category> list = new List<Model.category>();
            category cate = null;
            while (dr.Read())
            {
                cate = new category()
                {
                    catename = dr["cateName"].ToString(),
                    id = int.Parse(dr["id"].ToString()),
                    createTime = DateTime.Parse(dr["createTime"].ToString())
                };
                list.Add(cate);
            }
            dr.Close();
            return list;
        }

        public static DataTable getCategoryTable()
        {
            string sql = "SELECT [id],[catename] FROM[dbo].[Category]";
            DataTable dt = DBHelper.getDataTable(sql);
            return dt;
        }


        /// <summary>
        /// 模糊查询分类
        /// </summary>
        /// <param name="cate"></param>
        /// <returns></returns>
        public static List<category> getCateList(string cate)
        {
            string sql = $"select * from [category] where catename like '%{cate}%'";
            SqlDataReader dr = DBHelper.getData(sql);
            List<category> list = new List<category>();
            category c = null;
            while (dr.Read())
            {
                c = new category()
                {
                    id = dr.GetInt32(0),
                   catename=dr.GetString(1)
                };
                list.Add(c);
            }
            return list;
        }
        /// <summary>
        /// 修改分类
        /// </summary>
        /// <param name="c">实例化的category类</param>
        /// <returns></returns>
        public static bool UpdateCategory(category c)
        {
            string sql = $"update Category set catename='{c.catename}' where id={c.id}";
            return DBHelper.updateData(sql);
        }
    }
}