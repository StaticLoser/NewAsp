﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class adminService
    {
        public static admin CheckAdmin(string admin ,string password)
        {
            string sql = $"select * from admin where adminstorName='{admin}' and password='{password}'";
            SqlDataReader dr = DBHelper.getData(sql);
            admin a = null;
            if (dr.Read())
            {
                a = new admin()
                {
                    id=dr.GetInt32(0),
                    adminstorName=dr.GetString(1),
                    password=dr.GetString(2)
                };
            }
            dr.Close();
            return a;
        }

        /// <summary>
        /// 查询所有admin
        /// </summary>
        /// <returns>admin列表</returns>
        public static List<admin> getadmin()
        {
            string sql = "select * from admin";
            SqlDataReader dr = DBHelper.getData(sql);
            List<admin> list = new List<Model.admin>();
            admin cate = null;
            while (dr.Read())
            {
                cate = new admin()
                {                    
                    id = int.Parse(dr["id"].ToString()),
                    adminstorName=dr.GetString(1),
                   password=dr.GetString(2)
                };
                list.Add(cate);
            }
            dr.Close();
            return list;
        }
    }
}
