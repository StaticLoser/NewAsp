﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class LinkService
    {
        

        //id小于45
        public static List<Links> getNewsListLess45()
        {
            string sql = $"select  * from Links where id<45";
            SqlDataReader dr = DBHelper.getData(sql);
            List<Links> list = new List<Links>();
            Links link = null;
            while (dr.Read())
            {
                link = new Links()
                {
                    id = int.Parse(dr["id"].ToString()),
                    name = dr.GetString(1)
                };
                list.Add(link);
            }
            dr.Close();
            return list;
        }
        //id>45
        public static List<Links> getNewsListMore45()
        {
            string sql = $"select *from Links where id>45";
            SqlDataReader dr = DBHelper.getData(sql);
            List<Links> list = new List<Links>();
            Links link = null;
            while (dr.Read())
            {
                link = new Links()
                {
                    id = int.Parse(dr["id"].ToString()),
                    name = dr.GetString(1)
                };
                list.Add(link);
            }
            dr.Close();
            return list;
        }
    }
}
