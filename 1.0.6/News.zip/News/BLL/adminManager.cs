﻿using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public class adminManager
    {
        public static admin CheckAdmin(string admin, string password)
        {
            return adminService.CheckAdmin(admin, password);
        }
    }
}
