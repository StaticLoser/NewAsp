﻿using Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class adminService
    {
        public static admin CheckAdmin(string admin ,string password)
        {
            string sql = $"select * from admin where adminstorName='{admin}' and password='{password}'";
            SqlDataReader dr = DBHelper.getData(sql);
            admin a = null;
            if (dr.Read())
            {
                a = new admin()
                {
                    id=dr.GetInt32(0),
                    adminstorName=dr.GetString(1),
                    password=dr.GetString(2)
                };
            }
            dr.Close();
            return a;
        }        
    }
}
