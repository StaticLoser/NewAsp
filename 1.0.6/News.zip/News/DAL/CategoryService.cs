﻿using Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class CategoryService
    {
        //获取id<=7的分类信息
        public static List<category> GetCategoryList()
        {
            string sql = "select * from category where id<7";
            SqlDataReader dr = DBHelper.getData(sql);
            List<category> list = new List<Model.category>();
            category cate = null;
            while (dr.Read())
            {
                cate = new category()
                {
                    catename = dr["cateName"].ToString(),
                    id = int.Parse(dr["id"].ToString()),
                    createTime = DateTime.Parse(dr["createTime"].ToString())
                };
                list.Add(cate);
            }
            dr.Close();
            return list;
        }
        //获取id>7的分类信息
        public static List<category> GetCategoryListMore()
        {
            string sql = "select * from category where id>7";
            SqlDataReader dr = DBHelper.getData(sql);
            List<category> list = new List<Model.category>();
            category cate = null;
            while (dr.Read())
            {
                cate = new category()
                {
                    catename = dr["cateName"].ToString(),
                    id = int.Parse(dr["id"].ToString()),
                    createTime = DateTime.Parse(dr["createTime"].ToString())
                };
                list.Add(cate);
            }
            dr.Close();
            return list;
        }

        //查询所有分类信息
        public static List<category> getCategory()
        {
            string sql = "select * from category";
            SqlDataReader dr = DBHelper.getData(sql);
            List<category> list = new List<Model.category>();
            category cate = null;
            while (dr.Read())
            {
                cate = new category()
                {
                    catename = dr["cateName"].ToString(),
                    id = int.Parse(dr["id"].ToString()),
                    createTime = DateTime.Parse(dr["createTime"].ToString())
                };
                list.Add(cate);
            }
            dr.Close();
            return list;
        }

        public static DataTable getCategoryTable()
        {
            string sql = "SELECT [id] 分类id,[catename] 分类 ,[createtime] 修改时间 FROM[dbo].[Category]";
            DataTable dt = DBHelper.getDataTable(sql);
            return dt;
        }
    }
}