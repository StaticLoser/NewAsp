﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace DAL
{
    public class UserService
    {
        //增加用户
        public static bool addUser(User u)
        {
            string sql = $"insert into [user] (username,password,userAvatar,nickName,introduce,state,createTime) values('{u.username}','{u.password}','{u.userAvatar}','{u.nickName}','{u.introduce}','{u.state}','{u.createTime}')";

            return DBHelper.updateData(sql);
        }
        //修改用户
        public static bool updateData(User u)
        {
            string sql = $"update [user] set username='{u.username}',password='{u.password}',userAvatar='{u.userAvatar}',nickName='{u.nickName}',introduce='{u.introduce}',state='{u.state}',createTime='{u.createTime}'";
            return DBHelper.updateData(sql);
        }


        //用户修改信息
        public static bool updateUser(User u, string userAvatar, string nickName, string introduce)
        {
            string sql = $"update [user] set username='{u.username}',password='{u.password}',userAvatar='{userAvatar}',nickName='{nickName}',introduce='{introduce}',state='{u.state}',createTime='{u.createTime}' where username='{u.username}'";
            return DBHelper.updateData(sql);
        }

        //查询用户
        public static User getu(string userName)
        {
            string sql = $"select * from [user] where username='{userName}'";

            SqlDataReader dr = DBHelper.getData(sql);
            User u = null;
            if (dr.Read())
            {
                u = new User();
                u.id = dr.GetInt32(0);
                u.username = dr.GetString(1);
                u.password = dr.GetString(2);
                u.nickName = dr.GetString(3);
                u.userAvatar = dr.GetString(4);
                u.createTime = dr.GetDateTime(5);
                u.introduce = dr.GetString(6);
                u.state = dr.GetInt32(7);
            }
            return u;
        }

        public static DataTable getUserData()
        {
            string sql = "SELECT [id] 用户id ,[username] 用户名,[password] 密码,[nickName] 昵称,[createtime] 加入时间,[introduce]简介 FROM [dbo].[User]";
            DataTable dt = DBHelper.getDataTable(sql);
            return dt;
        }
    }
}
